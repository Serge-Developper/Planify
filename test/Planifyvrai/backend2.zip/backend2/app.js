// @ts-nocheck
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const fs = require('fs');

const app = express();

// Middleware CORS global
const whitelist = [
  'http://localhost:5173',
  'http://192.168.1.32:5173',
  'https://planify.tovmassian.but24.mmi-nancy.fr',
  'https://tovmassian.but24.mmi-nancy.fr',
  'https://8f4e-88-166-249-67.ngrok-free.app' // <-- Ajoute ici ton domaine ngrok
];
const corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1 || !origin) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  },
  credentials: true
}
app.use(cors(corsOptions));
app.use(express.json());

// Connexion à MongoDB
console.log('MONGO_URI =', process.env.MONGO_URI);
mongoose.connect(process.env.MONGO_URI || '')
  .then(() => console.log('Connecté à MongoDB'))
  .catch((err) => console.error('Erreur MongoDB :', err));

// Route de test
app.get('/', (req, res) => res.send('API Planifyvrai2 en ligne'));

const eventRoutes = require('./routes/events');
app.use('/events', eventRoutes);

const userRoutes = require('./routes/users');
app.use('/users', userRoutes);

app.options('*', cors(corsOptions));

// Lancement du serveur
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Serveur lancé sur le port ${PORT}`));
