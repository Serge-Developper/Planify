// @ts-nocheck
const express = require('express');
const router = express.Router();
const User = require('../models/User');
const jwt = require('jsonwebtoken');

// Connexion
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  console.log('Tentative de connexion pour:', username);
  console.log('Body reçu:', req.body);
  
  const user = await User.findOne({ username });
  if (!user) {
    console.log(`Utilisateur ${username} non trouvé`);
    return res.status(400).json({ message: 'Utilisateur non trouvé' });
  }
  
  if (user.password !== password) {
    console.log(`Mot de passe incorrect pour ${username}`);
    return res.status(400).json({ message: 'Mot de passe incorrect' });
  }

  console.log('User trouvé pour login:', user);

  console.log(`Connexion réussie pour ${username}:`, { role: user.role, groupe: user.groupe, year: user.year });

  // Créer le token JWT
  const token = jwt.sign(
    {
      id: user._id,
      username: user.username,
      role: user.role,
      year: user.year,
      groupe: user.groupe
    },
    process.env.JWT_SECRET || 'secret_key_default',
    { expiresIn: '24h' }
  );

  res.json({
    _id: user._id,
    username: user.username,
    role: user.role,
    groupe: user.groupe,
    year: user.year,
    token: token
  });
});

// Route pour créer des utilisateurs de test
router.post('/seed', async (req, res) => {
  try {
    // Supprimer les utilisateurs existants
    await User.deleteMany({});
    
    // Créer des utilisateurs de test
    const usersData = [
      { username: 'admin', password: 'admin123', role: 'admin', groupe: null, year: null },
      { username: 'étudiantA1', password: 'password', role: 'eleve', groupe: 'A', year: 'BUT1' },
      { username: 'étudiantB1', password: 'password', role: 'eleve', groupe: 'B', year: 'BUT1' },
      { username: 'delegueA', password: 'password', role: 'delegue', groupe: 'A', year: 'BUT1' },
      { username: 'prof1', password: 'password', role: 'prof', groupe: null, year: null }
    ];

    const users = await User.insertMany(usersData);
    res.json({ message: `${users.length} utilisateurs créés avec succès`, users: users.map(u => ({ username: u.username, role: u.role, groupe: u.groupe, year: u.year })) });
  } catch (error) {
    console.error('Erreur lors de la création des utilisateurs de test:', error);
    res.status(500).json({ message: 'Erreur lors de la création des utilisateurs de test', error: error.message });
  }
});

// Route pour voir tous les utilisateurs (debug)
router.get('/all', async (req, res) => {
  try {
    const users = await User.find({}, '-password'); // Exclure les mots de passe
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la récupération des utilisateurs', error: error.message });
  }
});

// Création d'utilisateurs
router.post('/register', async (req, res) => {
  const { username, password, role, groupe, year } = req.body;
  const user = new User({ username, password, role, groupe, year });
  await user.save();
  res.json(user);
});

module.exports = router; 