#!/bin/bash

# Script de déploiement pour Planify avec fonctionnalité avatar
echo "🚀 Déploiement de Planify avec fonctionnalité avatar..."

# Vérifier que les dépendances sont installées
echo "📦 Vérification des dépendances..."
if [ ! -d "node_modules" ]; then
    echo "Installation des dépendances..."
    npm install
fi

# Créer le dossier uploads s'il n'existe pas
echo "📁 Création du dossier uploads..."
mkdir -p uploads/avatars

# Vérifier que multer est installé
echo "🔍 Vérification de multer..."
if ! npm list multer > /dev/null 2>&1; then
    echo "Installation de multer..."
    npm install multer
fi

# Démarrer le serveur
echo "🌟 Démarrage du serveur..."
echo "✅ Backend prêt avec fonctionnalité avatar !"
echo "📝 Routes disponibles :"
echo "   - POST /api/users/upload-avatar (upload d'avatar)"
echo "   - GET /api/users/avatar/:userId (récupération d'avatar)"
echo "   - /uploads/avatars/ (serving statique des avatars)"

npm start 