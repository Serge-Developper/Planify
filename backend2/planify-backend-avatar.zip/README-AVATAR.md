# Planify Backend - Fonctionnalité Avatar

## 🚀 Déploiement

### Prérequis
- Node.js (version 14 ou supérieure)
- npm
- MongoDB

### Installation

1. **Installer les dépendances :**
   ```bash
   npm install
   ```

2. **Créer le dossier uploads :**
   ```bash
   mkdir -p uploads/avatars
   ```

3. **Configurer les variables d'environnement :**
   - Copier `env.example` vers `.env`
   - Configurer `MONGO_URI` et `JWT_SECRET`

4. **Démarrer le serveur :**
   ```bash
   npm start
   ```

## 📁 Structure des fichiers

```
backend2/
├── uploads/
│   └── avatars/          # Dossier des avatars uploadés
├── routes/
│   └── users.js          # Routes d'upload et récupération d'avatars
├── models/
│   └── User.js           # Modèle avec champ avatar
├── app.js                # Configuration multer et serving statique
└── package.json          # Dépendance multer ajoutée
```

## 🔧 Routes d'avatar

### Upload d'avatar
- **POST** `/api/users/upload-avatar`
- **Headers** : `Authorization: Bearer <token>`
- **Body** : `FormData` avec champ `avatar`
- **Limites** : 5MB max, images uniquement

### Récupération d'avatar
- **GET** `/api/users/avatar/:userId`
- **Retour** : Fichier image ou 404

### Serving statique
- **GET** `/uploads/avatars/<filename>`
- **Accès direct** aux fichiers uploadés

## 🛡️ Sécurité

- **Authentification** requise pour l'upload
- **Validation** du type de fichier (images uniquement)
- **Limitation** de taille (5MB)
- **Noms uniques** pour éviter les conflits
- **Suppression automatique** de l'ancien avatar

## 📝 Notes de déploiement

- Le dossier `uploads/avatars/` doit être créé sur le serveur
- Les permissions d'écriture doivent être configurées
- Pour IONOS/Plesk, vérifier que multer est installé
- Le serving statique est configuré dans `app.js`

## 🔄 Mise à jour

Pour mettre à jour le backend existant :

1. Remplacer les fichiers modifiés
2. Installer multer : `npm install multer`
3. Créer le dossier uploads
4. Redémarrer le serveur 